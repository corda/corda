/*
 * ProGuard -- shrinking, optimization, obfuscation, and preverification
 *             of Java bytecode.
 *
 * Copyright (c) 2002-2017 Eric Lafortune @ GuardSquare
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
package proguard.backport;

import proguard.classfile.*;
import proguard.classfile.constant.ClassConstant;

/**
 * Useful helpers for conversion of lambda expressions.
 *
 * @author Thomas Neidhart
 */
public class LambdaUtil
{
    public static final String SINGLETON_FIELD_NAME = "INSTANCE";

    private static final String LAMBDA_METAFACTORY   = "java/lang/invoke/LambdaMetafactory";
    private static final String METHOD_HANDLES_CLASS = "java/lang/invoke/MethodHandles";

    private static final String ALTERNATE_METAFACTORY_METHOD = "altMetafactory";

    private static final String LAMBDA_METHOD_PREFIX = "lambda$";

    private static final String METHOD_NAME_DESERIALIZE = "$deserializeLambda$";
    private static final String METHOD_TYPE_DESERIALIZE = "(Ljava/lang/invoke/SerializedLambda;)Ljava/lang/Object;";

    private LambdaUtil() {}


    public static boolean isLambdaMetaFactory(String className)
    {
        return LAMBDA_METAFACTORY.equals(className);
    }


    public static boolean isAlternateFactoryMethod(String methodName)
    {
        return ALTERNATE_METAFACTORY_METHOD.equals(methodName);
    }


    public static boolean isMethodHandleClass(ClassConstant classConstant, Clazz clazz)
    {
        return classConstant != null &&
               classConstant.getName(clazz).startsWith(METHOD_HANDLES_CLASS);
    }


    public static boolean isLambdaMethod(String methodName)
    {
        return methodName.startsWith(LAMBDA_METHOD_PREFIX);
    }


    public static boolean isDeserializationHook(Clazz clazz, Method method)
    {
        return method.getName(clazz).equals(METHOD_NAME_DESERIALIZE)       &&
               method.getDescriptor(clazz).equals(METHOD_TYPE_DESERIALIZE) &&
               hasFlag(method, ClassConstants.ACC_PRIVATE |
                               ClassConstants.ACC_STATIC  |
                               ClassConstants.ACC_SYNTHETIC);
    }


    // Private utility methods.

    private static boolean hasFlag(Member member, int flag)
    {
        return (member.getAccessFlags() & flag) == flag;
    }

}
