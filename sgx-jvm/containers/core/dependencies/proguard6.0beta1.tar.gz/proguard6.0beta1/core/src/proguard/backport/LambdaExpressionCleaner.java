/*
 * ProGuard -- shrinking, optimization, obfuscation, and preverification
 *             of Java bytecode.
 *
 * Copyright (c) 2002-2017 Eric Lafortune @ GuardSquare
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
package proguard.backport;

import proguard.classfile.*;
import proguard.classfile.attribute.*;
import proguard.classfile.attribute.visitor.*;
import proguard.classfile.constant.*;
import proguard.classfile.editor.*;
import proguard.classfile.util.SimplifiedVisitor;
import proguard.classfile.visitor.*;

import java.util.*;

/**
 * This ClassVisitor will remove any references to lambda
 * expressions from the visited classes.
 *
 * @author Thomas Neidhart
 */
public class LambdaExpressionCleaner
extends    SimplifiedVisitor
implements ClassVisitor,
           MemberVisitor,
           AttributeVisitor,
           BootstrapMethodInfoVisitor,
           InnerClassesInfoVisitor
{
    private final Object        removalMarker      = new Object();
    private final MemberRemover memberRemover      = new MemberRemover();
    private final List<String>  attributesToRemove = new ArrayList<String>();

    // Implementations for ClassVisitor.


    public void visitProgramClass(ProgramClass programClass)
    {
        attributesToRemove.clear();

        // Cleanup bootstrap method and inner classes attribute.
        programClass.attributesAccept(this);

        // Remove empty attributes
        if (!attributesToRemove.isEmpty())
        {
            AttributesEditor attributesEditor =
                new AttributesEditor(programClass, false);

            for (String attributeName : attributesToRemove)
            {
                attributesEditor.deleteAttribute(attributeName);
            }
        }

        // Remove lambda and deserialization methods.
        programClass.methodsAccept(this);
        memberRemover.visitProgramClass(programClass);

        // Remove all unused constant pool entries.
        programClass.accept(new ConstantPoolShrinker());
    }


    // Implementations for MemberVisitor.


    public void visitAnyMember(Clazz clazz, Member member) {}


    public void visitProgramMethod(ProgramClass programClass, ProgramMethod programMethod)
    {
        // remove deserialization hooks as they are not needed.
        if (LambdaUtil.isDeserializationHook(programClass, programMethod))
        {
            memberRemover.visitProgramMethod(programClass, programMethod);
        }
    }


    // Implementations for AttributeVisitor.


    public void visitAnyAttribute(Clazz clazz, Attribute attribute) {}


    public void visitInnerClassesAttribute(Clazz clazz, InnerClassesAttribute innerClassesAttribute)
    {
        // Mark inner class infos related to lambda expressions.
        innerClassesAttribute.innerClassesAccept(clazz, this);

        // Remove all marked inner classes.
        InnerClassesAttributeEditor editor =
            new InnerClassesAttributeEditor(innerClassesAttribute);
        for (int index = innerClassesAttribute.u2classesCount - 1; index >= 0; index--)
        {
            InnerClassesInfo innerClassesInfo = innerClassesAttribute.classes[index];
            if (shouldBeRemoved(innerClassesInfo))
            {
                editor.removeInnerClassesInfo(innerClassesInfo);
            }
        }

        // Remove the attribute if it is empty.
        if (innerClassesAttribute.u2classesCount == 0)
        {
            attributesToRemove.add(ClassConstants.ATTR_InnerClasses);
        }
    }


    public void visitBootstrapMethodsAttribute(Clazz clazz, BootstrapMethodsAttribute bootstrapMethodsAttribute)
    {
        // Mark bootstrap methods using the lambda meta factory.
        bootstrapMethodsAttribute.bootstrapMethodEntriesAccept(clazz, this);

        // Remove all marked bootstrap method infos.
        BootstrapMethodsAttributeEditor editor =
            new BootstrapMethodsAttributeEditor(bootstrapMethodsAttribute);
        for (int index = bootstrapMethodsAttribute.u2bootstrapMethodsCount - 1; index >= 0; index--)
        {
            BootstrapMethodInfo methodInfo = bootstrapMethodsAttribute.bootstrapMethods[index];
            if (shouldBeRemoved(methodInfo))
            {
                editor.removeBootstrapMethodInfo(methodInfo);
            }
        }

        // Remove the bootstrap method attribute if it is empty.
        if (bootstrapMethodsAttribute.u2bootstrapMethodsCount == 0)
        {
            attributesToRemove.add(ClassConstants.ATTR_BootstrapMethods);
        }
    }

    // Implementations for BootstrapMethodInfoVisitor.

    public void visitBootstrapMethodInfo(Clazz clazz, BootstrapMethodInfo bootstrapMethodInfo)
    {
        ProgramClass programClass = (ProgramClass) clazz;

        MethodHandleConstant bootstrapMethodHandle =
            (MethodHandleConstant) programClass.getConstant(bootstrapMethodInfo.u2methodHandleIndex);

        if (LambdaUtil.isLambdaMetaFactory(bootstrapMethodHandle.getClassName(clazz)))
        {
            markForRemoval(bootstrapMethodInfo);
        }
    }


    // Implementations for InnerClassesInfoVisitor.


    public void visitInnerClassesInfo(Clazz clazz, InnerClassesInfo innerClassesInfo)
    {
        ProgramClass programClass = (ProgramClass) clazz;

        ClassConstant innerClass =
            (ClassConstant) programClass.getConstant(innerClassesInfo.u2innerClassIndex);
        ClassConstant outerClass =
            (ClassConstant) programClass.getConstant(innerClassesInfo.u2outerClassIndex);

        if (LambdaUtil.isMethodHandleClass(innerClass, clazz) ||
            LambdaUtil.isMethodHandleClass(outerClass, clazz))
        {
            markForRemoval(innerClassesInfo);
        }
    }


    // Small utility methods

    private void markForRemoval(VisitorAccepter accepter)
    {
        accepter.setVisitorInfo(removalMarker);
    }


    private boolean shouldBeRemoved(VisitorAccepter accepter)
    {
        return accepter.getVisitorInfo() == removalMarker;
    }
}
